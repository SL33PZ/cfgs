### CHANGELOG

#### Version 0.2

* identify windows color schemes changes at runtime

#### Version 0.1

* send window colors information to Latte through dbus interface
